
import { 
  User, Compass, Heart, MessageCircle, Settings, ChevronRight, 
  MapPin, Briefcase, Ruler, GraduationCap, Wine, Cigarette, 
  Baby, Search, SlidersHorizontal, ShieldCheck, X, Check, Star, 
  Camera, ImagePlus, ChevronLeft, LogOut, Trash2, Zap, Eye, Bell, Lock,
  Plus, Sparkles, Pencil, MoreHorizontal, Share, BookOpen, Gamepad2, 
  Play, Pause, History, Video, Smile, Send, Upload, Download, File, Folder,
  CheckCheck, ArrowLeft, Mail, KeyRound, Loader2, AlertCircle, Info, MessageSquare,
  Ghost, Crown, Instagram, Twitter, Bot, Link, CheckCircle, Calendar, Sticker, Paperclip
} from 'lucide-react';

export const Icons = {
  User, Compass, Heart, MessageCircle, Settings, ChevronRight, 
  MapPin, Briefcase, Ruler, GraduationCap, Wine, Cigarette, 
  Baby, Search, SlidersHorizontal, ShieldCheck, X, Check, Star, 
  Camera, ImagePlus, ChevronLeft, LogOut, Trash2, Zap, Eye, Bell, Lock,
  Plus, Sparkles, Pencil, MoreHorizontal, Share, BookOpen, Gamepad2,
  Play, Pause, History, Video, Smile, Send, Upload, Download, File, Folder,
  CheckCheck, ArrowLeft, Mail, KeyRound, Loader2, AlertCircle, Info, MessageSquare,
  Ghost, Crown, Instagram, Twitter, Bot, Link, CheckCircle, Calendar, Sticker, Paperclip
};
